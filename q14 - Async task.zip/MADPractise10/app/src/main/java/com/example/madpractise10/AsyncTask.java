package com.example.madpractise10;


import android.graphics.Bitmap;

public abstract class AsyncTask<T, T1, T2> {

    protected abstract String doInBackground(Void... voids);



    protected abstract String execute(String result);

}
