package com.example.q9;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView t;
    EditText e;
    Button bt;
    Double res;
    Float rs;
    Double conTo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e = (EditText) findViewById(R.id.rs);
        t = (TextView) findViewById(R.id.result);
        bt = (Button) findViewById(R.id.button);


        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rs = Float.parseFloat(e.getText().toString());
                res = conTo * rs;
                t.setText(res+"");
            }
        });
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio1:
                if (checked)
                    conTo = 0.01225;
                break;
            case R.id.radio2:
                if (checked)
                    conTo = 0.01113;
                break;
            case R.id.radio3:
                if (checked)
                    conTo = 1.635;
                break;
        }
    }
}