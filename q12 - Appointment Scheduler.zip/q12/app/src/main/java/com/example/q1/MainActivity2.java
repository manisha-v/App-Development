package com.example.q1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView t1, t2, t3, t4, t5, t6, t7, t8, t9;
    String name, gen, mail, num, sp, drname, date, time, detail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        t1 = (TextView) findViewById(R.id.textView1);
        t2 = (TextView) findViewById(R.id.textView2);
        t3 = (TextView) findViewById(R.id.textView3);
        t4 = (TextView) findViewById(R.id.textView4);
        t5 = (TextView) findViewById(R.id.textView5);
        t6 = (TextView) findViewById(R.id.textView6);
        t7 = (TextView) findViewById(R.id.textView7);
        t8 = (TextView) findViewById(R.id.textView8);
        t9 = (TextView) findViewById(R.id.textView9);

        //Getting the Intent
        Intent i = getIntent();

        //Getting the Values from First Activity using the Intent received
        name = i.getStringExtra("name_key");
        gen = i.getStringExtra("gen_key");
        num = i.getStringExtra("num_key");
        mail = i.getStringExtra("mail_key");
        sp = i.getStringExtra("sp_key");
        drname = i.getStringExtra("drname_key");
        date = i.getStringExtra("date_key");
        time = i.getStringExtra("time_key");
        detail = i.getStringExtra("det_key");

        //Setting the Values to Intent
        t1.setText(name);
        t2.setText(gen);
        t4.setText(num);
        t3.setText(mail);
        t5.setText(sp);
        t6.setText(drname);
        t7.setText(date);
        t8.setText(time);
        t9.setText(detail);

    }
}