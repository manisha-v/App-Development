package com.example.q1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText e1,e2, e3, e4, e9;
    Button bt, datebt, timebt;
    Spinner docSp, docNm;

    //RadioGroup gen;

    String name, gender = "yo", mail, num, datest, timest, special, drname, detail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Referring the Views
        e1 = (EditText) findViewById(R.id.editText);
        e2 = (EditText) findViewById(R.id.editText2);
        e3 = (EditText) findViewById(R.id.editText3);
        e4 = (EditText) findViewById(R.id.editText4);
        e9 = (EditText) findViewById(R.id.editText9);

        datebt = (Button) findViewById(R.id.datepicker);
        timebt = (Button) findViewById(R.id.timepicker);

        //gen = (RadioGroup) findViewById(R.id.rad);
        RadioButton m = (RadioButton) findViewById(R.id.radio1);
        RadioButton f = (RadioButton) findViewById(R.id.radio2);
        if(m.isChecked())
            gender = "Male";
        else if(f.isChecked())
            gender = "Female";
        else
            gender= "hey";

        /*gender = (RadioButton) findViewById(gen.getCheckedRadioButtonId())
        switch (gen.getCheckedRadioButtonId()) {
            case R.id.radio1:
                gender = "Male";
                break;
            case R.id.radio2:
                gender = "Female";
                break;
        }*/

        docSp = (Spinner) findViewById(R.id.spinner1);
        docNm = (Spinner) findViewById(R.id.spinner2);

        docSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                special = parent.getItemAtPosition(position).toString();
                switch (special)
                {
                    case "Neurology":

                        // assigning div item list defined in XML to the div Spinner
                        docNm.setAdapter(new ArrayAdapter<String>(MainActivity.this,
                                android.R.layout.simple_spinner_dropdown_item,
                                getResources().getStringArray(R.array.items_name_sp1)));
                        break;

                    case "Dermatology":
                        docNm.setAdapter(new ArrayAdapter<String>(MainActivity.this,
                                android.R.layout.simple_spinner_dropdown_item,
                                getResources().getStringArray(R.array.items_name_sp2)));
                        break;

                    case "Pathology":
                        docNm.setAdapter(new ArrayAdapter<String>(MainActivity.this,
                                android.R.layout.simple_spinner_dropdown_item,
                                getResources().getStringArray(R.array.items_name_sp3)));
                        break;

                    case "Psychiatry":
                        docNm.setAdapter(new ArrayAdapter<String>(MainActivity.this,
                                android.R.layout.simple_spinner_dropdown_item,
                                getResources().getStringArray(R.array.items_name_sp4)));
                        break;
                }

                //set divSpinner Visibility to Visible
                docNm.setVisibility(View.VISIBLE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // can leave this empty
            }
        });

        // Div Spinner implementing onItemSelectedListener
        docNm.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                drname = parent.getItemAtPosition(position).toString();
                /*
                    Now that we have both values, lets create a Toast to
                    show the values on screen
                */
                /*Toast.makeText(MainActivity.this, "\n Class: \t " + selectedClass +
                        "\n Div: \t" + selectedDiv, Toast.LENGTH_LONG).show();*/
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // can leave this empty
            }

        });



        bt = (Button) findViewById(R.id.button);

        //Creating Listener for Button
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Getting the Values from Views(Edittext & Spinner)
                name = e1.getText().toString();
                mail = e2.getText().toString();
                num = e3.getText().toString() + e4.getText().toString();
                detail = e9.getText().toString();

                //Intent For Navigating to Second Activity
                Intent i = new Intent(MainActivity.this, MainActivity2.class);

                //For Passing the Values to Second Activity
                i.putExtra("name_key", name);
                i.putExtra("mail_key", mail);
                i.putExtra("num_key", num);
                i.putExtra("gen_key", gender);
                i.putExtra("date_key", datest);
                i.putExtra("time_key", timest);
                i.putExtra("sp_key", special);
                i.putExtra("drname_key",drname);
                i.putExtra("det_key", detail);

                startActivity(i);

            }
        });
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio1:
                if (checked)
                    gender = "Male";
                    break;
            case R.id.radio2:
                if (checked)
                    gender = "Female";
                    break;
        }
    }

    public void showDatePicker(View view) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(),"datePicker");
    }

    public void processDatePickerResult(int year, int month, int day) {
        String month_string = Integer.toString(month+1);
        String day_string = Integer.toString(day);
        String year_string = Integer.toString(year);
        datest = month_string + "/" + day_string + "/" + year_string;
        datebt.setText(datest);
        Toast.makeText(this, "Date: " + datest,
                Toast.LENGTH_SHORT).show();

    }

    public void showTimePicker(View view) {
        DialogFragment newFragment = new TimePickerFragment();
        newFragment.show(getSupportFragmentManager(),"timePicker");
    }

    public void processTimePickerResult(int hour, int minute, String ampm) {
        String min_string = Integer.toString(minute);
        String hour_string = Integer.toString(hour);
        timest = hour_string + ":" + min_string + " " + ampm;
        timebt.setText(timest);
        Toast.makeText(this, "Time: " + timest,
                Toast.LENGTH_SHORT).show();
    }
}