package com.example.q5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button bt;
    Spinner s;

    RatingBar rating;
    float rateVal;

    //Data for populating in Spinner
    String [] movies={"Jab We Met", "Raanjhana","Inception","Your Name", "Gravity", "Dhamaal"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Referring the Views
        bt= (Button) findViewById(R.id.button);
        rating = (RatingBar) findViewById(R.id.rate);
        s= (Spinner) findViewById(R.id.spinner);

        //Creating Adapter for Spinner for adapting the data from array to Spinner
        ArrayAdapter adapter= new ArrayAdapter(MainActivity.this, android.R.layout.simple_spinner_item,movies);
        s.setAdapter(adapter);



        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rateVal = rating.getRating();
                Toast.makeText(MainActivity.this,s.getSelectedItem().toString() +
                        " rating " + rateVal, Toast.LENGTH_LONG).show();

            }
        });
    }
}