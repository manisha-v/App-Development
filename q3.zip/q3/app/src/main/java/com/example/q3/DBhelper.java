package com.example.q3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.sql.SQLClientInfoException;

public class DBhelper extends SQLiteOpenHelper {

    public static final String DBNAME = "login.db";

    public DBhelper(Context context){
        super(context,"login.db",null,1);

    }
    @Override
    public void onCreate(SQLiteDatabase mydb) {
        mydb.execSQL("create Table users(username TEXT primary key, password TEXT)");
        insertData("Manisha", "mani");
        insertData("Naren", "nare");
        insertData("Disha", "dish");
        insertData("Gunjan", "gunj");
        insertData("Siddharth", "sid");
    }

    @Override
    public void onUpgrade(SQLiteDatabase mydb, int i, int i1) {
        mydb.execSQL("drop Table if exists users");
    }

    public Boolean insertData(String name, String pw){
        SQLiteDatabase mydb = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username",name);
        contentValues.put("password",pw);
        long res = mydb.insert("users", null, contentValues);
        if(res ==-1)
            return false;
        else
            return true;

    }
    public Boolean checkuserpw(String name, String pw){
        SQLiteDatabase mydb = this.getWritableDatabase();
        Cursor cur = mydb.rawQuery("select * from users where username = ? and password = ?", new String[]{name,pw});
        if(cur.getCount()>0)
            return true;
        return false;
    }
}

