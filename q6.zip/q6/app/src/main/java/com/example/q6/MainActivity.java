package com.example.q6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    String section;
    SeekBar bar;
    TextView t;
    Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t = (TextView) findViewById(R.id.prog);
        bar = (SeekBar) findViewById(R.id.bar);
        bt = (Button) findViewById(R.id.button);

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                t.setText(i + " %");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int progress = bar.getProgress();
                Toast.makeText(MainActivity.this,section +
                        " students progess is " + progress + " %", Toast.LENGTH_LONG).show();

            }
        });
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio1:
                if (checked)
                    section = "Section A";
                break;
            case R.id.radio2:
                if (checked)
                    section = "Section B";
                break;
            case R.id.radio3:
                if (checked)
                    section = "Section C";
                break;
            case R.id.radio4:
                if (checked)
                    section = "Section D";
                break;
        }
    }
}