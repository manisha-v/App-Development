package com.example.q8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    EditText len;
    TextView res;
    int conTo;
    Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        len = (EditText) findViewById(R.id.len);
        res = (TextView) findViewById(R.id.bill);
        bt = (Button) findViewById(R.id.button);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float l = Float.parseFloat(len.getText().toString());
                res.setText(l*conTo + " rs");
            }
        });

    }
    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio1:
                if (checked)
                    conTo = 500;
                break;
            case R.id.radio2:
                if (checked)
                    conTo = 100;
                break;
            case R.id.radio3:
                if (checked)
                    conTo = 1000;
                break;
        }
    }
}