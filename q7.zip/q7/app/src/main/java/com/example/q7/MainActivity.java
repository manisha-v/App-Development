package com.example.q7;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //TextView tv1,tv2,tv3,tv4;
    TextView t;
    int d;
    final static String ds = "dis";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /*tv1 = (TextView) findViewById(R.id.t1);
        tv2 = (TextView) findViewById(R.id.t2);
        tv3 = (TextView) findViewById(R.id.t3);
        tv4 = (TextView) findViewById(R.id.t4);*/
        t = (TextView) findViewById(R.id.t1);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState != null) {
            d = savedInstanceState.getInt(ds);

            //Set the score text views.
            t.setText(String.valueOf(d));
        }

    }
    public void carDis(View view) {
        /*tv1.setText("7 hrs");
        tv2.setText(" ");
        tv3.setText(" ");
        tv4.setText(" ");*/
        d=40;
        t.setText(String.valueOf(d));
    }
/*
    public void bikeDis(View view) {
        tv1.setText(" ");
        tv2.setText("9 hrs");
        tv3.setText(" ");
        tv4.setText(" ");
    }
    public void busDis(View view) {
        tv1.setText(" ");
        tv2.setText(" ");
        tv3.setText("6 hrs");
        tv4.setText(" ");
    }
    public void walkDis(View view) {
        t1.setText(" ");
        t2.setText(" ");
        t3.setText(" ");
        Toast.makeText(MainActivity.this, "40 hrs", Toast.LENGTH_LONG).show();
    }*/
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putInt(ds, d);
        super.onSaveInstanceState(outState);
    }
    
}