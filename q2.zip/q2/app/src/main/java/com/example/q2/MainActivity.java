package com.example.q2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText am, in;
    TextView p, res1,res2,res3;

    Button sub, res;
    int period;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        am = (EditText) findViewById(R.id.editText);
        in = (EditText) findViewById(R.id.editText2);
        sub = (Button) findViewById(R.id.button1);
        res = (Button) findViewById(R.id.button2);
        p = (TextView)findViewById(R.id.text3);
        res1 = (TextView) findViewById(R.id.rowv1);
        res2 = (TextView) findViewById(R.id.rowv2);
        res3 = (TextView) findViewById(R.id.rowv3);
        period=0;
        // set a listener
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                float amt = 0;
                float intr = 0;
                float per = 0;
                double emi = 0, tin=0,tpay = 0;

                // check if the fields are empty
                if (TextUtils.isEmpty(am.getText().toString()) || TextUtils.isEmpty(in.getText().toString()))
                    return;

                // read EditText and fill variables with numbers
                amt = Float.parseFloat(am.getText().toString());
                intr = Float.parseFloat(in.getText().toString())/100;
                per = Float.parseFloat(p.getText().toString()) * 12;

                emi = (amt*intr*Math.pow((1+intr),per))/(Math.pow(1+intr, per)-1);
                tin = amt*intr*per;
                tpay = emi*per;

                res1.setText(""+Math.floor(emi * 100) / 100);
                res2.setText(""+Math.floor(tin * 100) / 100);
                res3.setText(""+Math.floor(tpay * 100) / 100);
            }
        });

        res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                am.setText("");
                in.setText("");
                period = 0;
                p.setText("");
                res1.setText("000000");
                res2.setText("000000");
                res3.setText("000000");
            }
        });

    }

    public void decreasePeriod(View view) {
        period--;
        p.setText(String.valueOf(period));
    }

    public void increasePeriod(View view) {
        period++;
        p.setText(String.valueOf(period));
    }


}