package com.example.distance;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.material.chip.Chip;

public class MainActivity extends AppCompatActivity {

    EditText source,dest;
    Chip car,bike,train,walk;
    TextView carText,bikeText,trainText,walkText;
    ImageButton dir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        source=(EditText) findViewById(R.id.source);
        dest=(EditText) findViewById(R.id.dest);
        car=(Chip) findViewById(R.id.carChip);
        bike=(Chip) findViewById(R.id.bikeChip);
        train=(Chip) findViewById(R.id.trainChip);
        walk=(Chip) findViewById(R.id.walkChip);
        carText=(TextView) findViewById(R.id.car);
        bikeText=(TextView) findViewById(R.id.bike);
        trainText=(TextView) findViewById(R.id.train);
        walkText=(TextView) findViewById(R.id.walk);
        dir=(ImageButton) findViewById(R.id.imageButton);

        dir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s1=source.getText().toString();
                String s2=dest.getText().toString();
                source.setText(s2);
                dest.setText(s1);
            }
        });

        car.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                carText.setText("7 hrs");
                bikeText.setText("");
                trainText.setText("");
                walkText.setText("");
            }
        });

        bike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                bikeText.setText("9 hrs");
                carText.setText("");
                trainText.setText("");
                walkText.setText("");
            }
        });

        train.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                trainText.setText("6 hrs");
                carText.setText("");
                bikeText.setText("");
                walkText.setText("");
            }
        });

        walk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                walkText.setText("40 hrs");
                carText.setText("");
                trainText.setText("");
                bikeText.setText("");
            }
        });
    }
}