package com.example.endexam;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    String name,roll,n;
    Button bt;

    EditText[] ed;
    //LinearLayout linear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent i = getIntent();

        //Getting the Values from First Activity using the Intent received
        name = i.getStringExtra("name_key");
        roll = i.getStringExtra("roll");
        n = i.getStringExtra("subs");
        bt = (Button) findViewById(R.id.button);
        LinearLayout linear = (LinearLayout) findViewById(R.id.linText);

        int num = Integer.parseInt(n);
        ed = new EditText[num];
        for(int ind=0; ind<num; ind++){
            ed[ind] = new EditText(MainActivity2.this);
            ed[ind].setBackgroundResource(R.color.black);
            ed[ind].setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            linear.addView(ed[ind]);
        }
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity2.this, name + " "+ roll + " is registered for "+n +" subjects", Toast.LENGTH_SHORT).show();
            }
        });
    }
}