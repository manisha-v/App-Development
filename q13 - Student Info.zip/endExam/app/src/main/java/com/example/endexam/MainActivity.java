package com.example.endexam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    EditText n,b,c,ns,rn,sp;
    RadioButton r1,r2;
    Spinner spin;
    Button bt;

    String name,roll,branch,course,subs,year,spec;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        n = (EditText) findViewById(R.id.editText);
        rn = (EditText) findViewById(R.id.editText2);
        b = (EditText) findViewById(R.id.editText4);
        sp = (EditText) findViewById(R.id.editText5);
        ns = (EditText) findViewById(R.id.editText6);
        r1 = (RadioButton) findViewById(R.id.radio1);
        r2 = (RadioButton) findViewById(R.id.radio2);
        bt = (Button) findViewById(R.id.button);
        spin = (Spinner) findViewById(R.id.spinner2);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name = n.getText().toString();
                roll = rn.getText().toString();
                branch = b.getText().toString();
                spec = sp.getText().toString();
                subs = ns.getText().toString();

                Intent i = new Intent(MainActivity.this, MainActivity2.class);

                //For Passing the Values to Second Activity
                i.putExtra("name_key", name);
                i.putExtra("roll", roll);
                i.putExtra("subs", subs);

                startActivity(i);

            }
        });

        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                year = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // can leave this empty
            }

        });


    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio1:
                course = "UG";
                spin.setAdapter(new ArrayAdapter<String>(MainActivity.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        getResources().getStringArray(R.array.c1)));
                break;
            case R.id.radio2:
                course = "PG";
                spin.setAdapter(new ArrayAdapter<String>(MainActivity.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        getResources().getStringArray(R.array.c2)));
                break;
        }
        spin.setVisibility(View.VISIBLE);

    }
}